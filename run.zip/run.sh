#!/bin/bash

# Build le projet
mvn clean install

# Copier le WAR dans Tomcat
cp  test/target/test-sprint_1.war /media/tsialone/Data/ITU/L3/S5/Mr_Naina/server/apache-tomcat-10.1.46/webapps/
